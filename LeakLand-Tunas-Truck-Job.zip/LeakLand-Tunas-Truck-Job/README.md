# FiveM---Tunas-Truck-Job
Point A to B to C ... sometimes D ... A simple ESX trucking script

TO GET STARTED 
1.) Simply upload the TunasTruckJob to your /resource directory
2.) Add ensure TunasTruckJob to your server.cfg file
3.) Adjust uniform in utils.lua (refer to video to honor my existence)

https://www.youtube.com/channel/UCqoEtIuzJc3PGk9YX6kslNw
